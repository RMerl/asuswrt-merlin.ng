/*
 * Copyright (c) 2014-2016, ARM Limited and Contributors. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#if ERROR_DEPRECATED
#error "Using deprecated TZC-400 source file"
#else
#include "../tzc/tzc400.c"
#endif /* ERROR_DEPRECATED */
