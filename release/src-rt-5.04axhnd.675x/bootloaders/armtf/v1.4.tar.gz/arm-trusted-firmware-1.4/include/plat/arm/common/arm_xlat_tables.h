/*
 * Copyright (c) 2017, ARM Limited and Contributors. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#if ARM_XLAT_TABLES_LIB_V1
#include <xlat_tables.h>
#else
#include <xlat_tables_v2.h>
#endif /* ARM_XLAT_TABLES_LIB_V1 */
