/*
 * Copyright (c) 2015-2016, ARM Limited and Contributors. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#if !ERROR_DEPRECATED
#include "../plat_psci_common.c"
#endif
