#pragma once

int simple_print(const char *msg, const long bufsize);

int simple_strlen(const char *str);
