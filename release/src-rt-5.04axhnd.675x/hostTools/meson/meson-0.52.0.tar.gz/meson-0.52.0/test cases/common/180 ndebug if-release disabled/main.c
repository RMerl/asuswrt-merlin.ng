#include <assert.h>
#include <stdlib.h>

int main(void) {
    assert(0);
    return EXIT_SUCCESS;
}
