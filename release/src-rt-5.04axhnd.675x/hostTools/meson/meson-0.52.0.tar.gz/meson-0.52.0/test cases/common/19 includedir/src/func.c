#include "func.h"

int func() {
    return 0;
}
