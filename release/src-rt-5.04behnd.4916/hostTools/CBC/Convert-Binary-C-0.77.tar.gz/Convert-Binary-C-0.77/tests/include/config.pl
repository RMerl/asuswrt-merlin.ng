{
  Include => ['tests/include/gccinc', 'tests/include/include', 'tests/include/perlinc'],
  Define  => ['__builtin_va_list=int'],
};
