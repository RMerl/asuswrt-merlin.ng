#ifdef TEST
#include <something.h>
struct bar { int foo; };
#endif
