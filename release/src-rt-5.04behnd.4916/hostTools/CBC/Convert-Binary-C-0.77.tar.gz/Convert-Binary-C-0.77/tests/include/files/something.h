struct foo { int bar; };
