??=define FOO
#ifdef FOO
typedef char array??(42??);
#endif
