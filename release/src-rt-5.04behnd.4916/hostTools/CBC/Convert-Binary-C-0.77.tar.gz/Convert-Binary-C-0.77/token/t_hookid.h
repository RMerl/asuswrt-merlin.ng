enum HookId {
  HOOKID_pack,
  HOOKID_unpack,
  HOOKID_pack_ptr,
  HOOKID_unpack_ptr,
  HOOKID_COUNT,
  HOOKID_INVALID 
};
