typedef int foo;
