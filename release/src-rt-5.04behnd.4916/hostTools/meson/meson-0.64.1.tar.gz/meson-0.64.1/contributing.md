## Contributing to the Meson build system

Thank you for your interest in participating to the development!
A large fraction of Meson is contributed by people outside
the core team and we are *excited* to see what you do.

**Contribution instructions can be found on the website**
 @ https://mesonbuild.com/Contributing.html
