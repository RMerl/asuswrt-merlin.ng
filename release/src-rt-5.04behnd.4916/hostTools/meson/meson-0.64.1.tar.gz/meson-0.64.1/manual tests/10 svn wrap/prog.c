#include"subproj.h"

int main(void) {
    subproj_function();
    return 0;
}
