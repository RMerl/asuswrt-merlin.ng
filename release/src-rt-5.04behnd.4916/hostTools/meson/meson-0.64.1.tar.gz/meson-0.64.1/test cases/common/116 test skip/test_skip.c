int main(void) {
    return 77;
}
