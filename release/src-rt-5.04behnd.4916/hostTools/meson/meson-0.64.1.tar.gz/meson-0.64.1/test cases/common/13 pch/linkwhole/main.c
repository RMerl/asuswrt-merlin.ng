#include<stdio.h>

void func1();

int main(int argc, char **argv) {
    printf("Calling func1\n");
    func1();
    return 0;
}
