#ifndef HELLO_H_
#define HELLO_H_

#include <cstdint>

void print_cbor_version(void);

#endif  // HELLO_H_
