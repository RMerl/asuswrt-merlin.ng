#include "src/hello.h"

#include <stdio.h>

int main() {
  print_cbor_version();
  
  return 0;
}

