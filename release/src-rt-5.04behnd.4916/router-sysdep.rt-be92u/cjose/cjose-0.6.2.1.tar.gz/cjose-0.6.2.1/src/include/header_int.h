/*!
 * Copyrights
 *
 * Portions created or assigned to Cisco Systems, Inc. are
 * Copyright (c) 2014-2016 Cisco Systems, Inc.  All Rights Reserved.
 */

#ifndef SRC_HEADER_INT_H
#define SRC_HEADER_INT_H

// extern const char *CJOSE_HDR_ATTRS[];

#endif // SRC_HEADER_INT_H
